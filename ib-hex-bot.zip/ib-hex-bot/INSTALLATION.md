# 📦 INSTALLATION IB-HEX-BOT

## 📋 Prérequis

- Node.js v16+ installé
- Compte GitHub
- Compte Render (gratuit)
- Téléphone WhatsApp

## 🚀 Installation Rapide

### 1. Extraire les fichiers

Extrayez le fichier ZIP dans un dossier :
```
ib-hex-bot/
```

### 2. Installer les dépendances

```bash
cd ib-hex-bot
npm install
```

### 3. Tester localement (Optionnel)

```bash
npm start
```

Visitez `http://localhost:3000` et scannez le QR code pour tester.

### 4. Déployer sur Render

Suivez le guide complet dans `DEPLOYMENT.md`

## 🎯 Configuration

Modifiez `config.js` selon vos besoins :

```javascript
export default {
    PREFIX: 'Ib',              // Préfixe des commandes
    OWNER_NUMBER: '224621963059',  // VOTRE numéro
    BOT_NAME: 'IB-HEX-BOT',
    OWNER_NAME: 'Ibrahima Sory Sacko',
    VERSION: '1.0',
    MODE: 'privé',
    MENU_IMAGE: 'https://i.ibb.co/fYbBRWyy/IMG-20260210-WA0152.jpg',
    PORT: process.env.PORT || 3000
}
```

## 📱 Utilisation

Une fois déployé et connecté, utilisez les commandes avec le préfixe `Ib` :

```
Ibmenu          # Afficher le menu
Ibping          # Tester la vitesse
Ibtagall        # Mentionner tous (groupe)
Iballcmds       # Liste des 200+ commandes
```

## 🔧 Commandes Importantes

### Menu
- `Ibmenu` - Menu complet avec image
- `Ibalive` - Vérifier si le bot fonctionne
- `Ibping` - Vitesse de réponse

### Owner
- `Ib🥷` - Vue unique privé (téléchargement direct)
- `Ibvv` - Vue unique normale
- `Iballcmds` - Toutes les commandes
- `Ibrepo` - Informations du dépôt

### Groupes
- `Ibtagall` - Mentionner tous les membres
- `Ibtagadmin` - Mentionner les admins
- `Ibkickall` - Exclure tous les membres
- `Iblinkgc` - Lien du groupe

## 🌟 Fonctionnalités

✅ **200+ commandes opérationnelles**
✅ **Préfixe obligatoire "Ib"**
✅ **Interface web pour QR Code**
✅ **Multi-device WhatsApp**
✅ **Hébergement gratuit sur Render**
✅ **100% en français**

## 📊 Structure du Projet

```
ib-hex-bot/
├── commands/           # Toutes les commandes (200+)
│   ├── menu/          # Commandes menu (6)
│   ├── owner/         # Commandes propriétaire (9)
│   ├── ia/            # IA (6)
│   ├── converter/     # Convertisseurs (9)
│   ├── search/        # Recherche (10)
│   ├── fun/           # Divertissement (9)
│   ├── group/         # Groupes (13)
│   ├── reactions/     # Réactions (10)
│   ├── extra/         # Extra (68)
│   └── effects/       # Effets (136)
├── utils/             # Utilitaires
├── config.js          # Configuration
├── index.js           # Point d'entrée
├── package.json       # Dépendances
├── README.md          # Documentation
├── DEPLOYMENT.md      # Guide déploiement
└── INSTALLATION.md    # Ce fichier
```

## ❓ FAQ

### Le bot ne répond pas ?
- Vérifiez que vous utilisez le préfixe `Ib`
- Le bot ne répond qu'aux messages avec le préfixe

### Comment changer le préfixe ?
Modifiez `PREFIX` dans `config.js` :
```javascript
PREFIX: 'VotrePréfixe',
```

### Le QR code ne s'affiche pas ?
- Vérifiez que le port 3000 est libre
- Consultez les logs avec `npm start`
- Sur Render, vérifiez que le service est actif

### Comment ajouter des commandes ?
1. Créez un fichier dans `commands/[categorie]/`
2. Utilisez le template existant
3. Ajoutez l'export dans `commands/index.js`
4. Ajoutez dans `messageHandler.js`

## 🆘 Support

📞 **WhatsApp:** 224621963059  
👨‍💻 **Développeur:** Ibrahima Sory Sacko  
📧 **Email:** Contactez via WhatsApp

## 📝 Licence

Développé par Ibrahima Sory Sacko  
Open Source - Utilisation libre

---

⚡ **IB-HEX-BOT v1.0** - Propulsé par Ibrahima Sory Sacko™ 🥷
