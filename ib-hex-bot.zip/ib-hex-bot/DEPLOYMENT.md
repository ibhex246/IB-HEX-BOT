# 🚀 GUIDE DE DÉPLOIEMENT - IB-HEX-BOT SUR RENDER

## Étape 1 : Créer un dépôt GitHub

1. Allez sur https://github.com
2. Cliquez sur "New repository"
3. Nom : `ib-hex-bot`
4. Description : "Bot WhatsApp Multi-Device avec 200+ commandes"
5. Public
6. Cliquez "Create repository"

## Étape 2 : Pousser le code vers GitHub

```bash
cd ib-hex-bot
git init
git add .
git commit -m "Initial commit - IB-HEX-BOT"
git branch -M main
git remote add origin https://github.com/VOTRE_USERNAME/ib-hex-bot.git
git push -u origin main
```

## Étape 3 : Déployer sur Render

1. **Créer un compte Render**
   - Allez sur https://render.com
   - Cliquez sur "Get Started"
   - Inscrivez-vous avec GitHub

2. **Créer un nouveau Web Service**
   - Dans le dashboard, cliquez sur "New +"
   - Sélectionnez "Web Service"
   - Connectez votre dépôt GitHub `ib-hex-bot`
   - Autorisez Render à accéder au dépôt

3. **Configuration du Service**
   ```
   Name: ib-hex-bot
   Region: Frankfurt (EU Central) ou Oregon (US West)
   Branch: main
   Runtime: Node
   Build Command: npm install
   Start Command: npm start
   Plan: Free
   ```

4. **Variables d'environnement** (optionnel)
   - Cliquez sur "Advanced"
   - Ajoutez les variables si nécessaire
   - `NODE_ENV` = `production`

5. **Déployer**
   - Cliquez sur "Create Web Service"
   - Attendez la fin du déploiement (3-5 minutes)

## Étape 4 : Scanner le QR Code

1. Une fois déployé, copiez l'URL de votre service
   - Ex: `https://ib-hex-bot.onrender.com`

2. Ouvrez l'URL dans votre navigateur
   - Vous verrez la page avec le QR Code

3. Scanner avec WhatsApp
   - Ouvrez WhatsApp sur votre téléphone
   - Allez dans **Paramètres > Appareils liés**
   - Appuyez sur **Lier un appareil**
   - Scannez le QR Code

4. Attendez la connexion
   - Le bot devrait se connecter automatiquement
   - Vous verrez "IB-HEX-BOT Connecté !" sur la page

## Étape 5 : Tester le Bot

Envoyez un message WhatsApp :
```
Ibmenu
```

Le bot devrait répondre avec le menu complet !

## ⚠️ Important

- **Render Free Tier** : Le service peut s'endormir après 15 minutes d'inactivité
- Pour le garder actif : utilisez un service comme UptimeRobot pour ping régulier
- L'authentification persiste : une fois connecté, le bot reste actif

## 🔧 Maintenance

### Voir les logs
1. Allez dans votre dashboard Render
2. Cliquez sur votre service
3. Cliquez sur "Logs" dans la navigation

### Redémarrer le bot
1. Dans le dashboard
2. Cliquez sur "Manual Deploy"
3. Sélectionnez "Clear build cache & deploy"

### Mettre à jour le code
```bash
git add .
git commit -m "Update bot"
git push
```
Render redéploiera automatiquement !

## 📱 Utilisation

Toutes les commandes commencent par `Ib` :

- `Ibmenu` - Menu complet
- `Ibping` - Vitesse du bot
- `Ibtagall` - Mentionner tous (dans un groupe)
- `Iballcmds` - Liste toutes les 200+ commandes

## 🆘 Dépannage

### Le QR Code ne s'affiche pas
- Vérifiez que le service est bien démarré dans Render
- Consultez les logs pour voir les erreurs

### Le bot ne répond pas
- Vérifiez que le préfixe `Ib` est bien utilisé
- Le bot ne répond qu'aux messages avec le préfixe

### Erreur de connexion
- Déconnectez l'appareil lié dans WhatsApp
- Redémarrez le service sur Render
- Scannez à nouveau le QR code

## 🎉 C'est Tout !

Votre IB-HEX-BOT est maintenant en ligne 24/7 sur Render !

Pour toute question:
📞 WhatsApp: 224621963059
👨‍💻 Développeur: Ibrahima Sory Sacko

---
⚡ IB-HEX-BOT - Propulsé par Ibrahima Sory Sacko™ 🥷
