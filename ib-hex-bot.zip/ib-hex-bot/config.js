export default {
    PREFIX: 'Ib',
    OWNER_NUMBER: '224621963059',
    BOT_NAME: 'IB-HEX-BOT',
    OWNER_NAME: 'Ibrahima Sory Sacko',
    VERSION: '1.0',
    MODE: 'privé',
    DEVELOPER: 'ibrahima sory sacko',
    
    // Menu Image
    MENU_IMAGE: 'https://i.ibb.co/fYbBRWyy/IMG-20260210-WA0152.jpg',
    
    // Auto-reply settings
    AUTO_READ: true,
    AUTO_TYPING: true,
    
    // API Keys (ajouter les vôtres)
    GOOGLE_API_KEY: '',
    OPENAI_API_KEY: '',
    GEMINI_API_KEY: '',
    
    // Port pour le serveur web
    PORT: process.env.PORT || 3000
}
