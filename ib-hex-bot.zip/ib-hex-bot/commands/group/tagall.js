import config from '../../config.js'

export async function tagall(sock, message) {
    const remoteJid = message.key.remoteJid
    if (!remoteJid.includes('@g.us')) {
        await sock.sendMessage(remoteJid, {
            text: '❌ Cette commande ne fonctionne que dans les groupes!'
        })
        return
    }

    try {
        const groupMetadata = await sock.groupMetadata(remoteJid)
        const participants = groupMetadata.participants.map(user => user.id)
        const text = participants.map(user => `@${user.split('@')[0]}`).join('\n')

        await sock.sendMessage(remoteJid, {
            text: `╭─⌈ 🚀 IB-HEX-BOT Mention ⌋\n│\n${text}\n│\n╰─⌊ Propulsé par ${config.OWNER_NAME} ⌉`,
            mentions: participants
        })

    } catch (error) {
        console.error("Erreur tagall:", error)
        await sock.sendMessage(remoteJid, {
            text: '❌ Erreur lors de la mention de tous'
        })
    }
}
