import config from '../../config.js'

export async function tagadmin(sock, message) {
    const remoteJid = message.key.remoteJid
    const botNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net'
    
    if (!remoteJid.includes('@g.us')) {
        await sock.sendMessage(remoteJid, {
            text: '❌ Cette commande ne fonctionne que dans les groupes!'
        })
        return
    }

    try {
        const { participants } = await sock.groupMetadata(remoteJid)
        const admins = participants.filter(p => p.admin && p.id !== botNumber).map(p => p.id)
        
        if (admins.length === 0) {
            await sock.sendMessage(remoteJid, {
                text: '❌ Aucun admin trouvé dans ce groupe'
            })
            return
        }

        const text = `╭─⌈ 🛡️ IB-HEX-BOT Alerte Admin ⌋\n│ Alerte Administrateurs\n│\n${admins.map(user => `@${user.split('@')[0]}`).join('\n')}\n│\n╰─⌊ ${config.BOT_NAME} ⌉`

        await sock.sendMessage(remoteJid, { text, mentions: admins })

    } catch (error) {
        console.error("Erreur tagadmin:", error)
        await sock.sendMessage(remoteJid, {
            text: '❌ Erreur lors de la mention des admins'
        })
    }
}
