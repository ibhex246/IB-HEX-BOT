import { downloadMediaMessage } from '@whiskeysockets/baileys'
import config from '../../config.js'

export async function vv2(sock, message) {
    const remoteJid = message.key.remoteJid
    const senderNumber = message.key.participant || message.key.remoteJid
    const ownerJid = config.OWNER_NUMBER + '@s.whatsapp.net'

    try {
        // Vérifier si c'est un message avec vue unique
        const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage
        
        if (!quotedMessage) {
            await sock.sendMessage(remoteJid, {
                text: '❌ Répondez à un message avec vue unique!'
            })
            return
        }

        const viewOnceMessage = quotedMessage.viewOnceMessage || quotedMessage.viewOnceMessageV2

        if (!viewOnceMessage) {
            await sock.sendMessage(remoteJid, {
                text: '❌ Ce n\'est pas un message avec vue unique!'
            })
            return
        }

        await sock.sendMessage(remoteJid, {
            text: '⏳ Téléchargement en cours...'
        })

        // Extraire le média
        const mediaType = viewOnceMessage.message?.imageMessage ? 'image' : 
                         viewOnceMessage.message?.videoMessage ? 'video' : null

        if (!mediaType) {
            await sock.sendMessage(remoteJid, {
                text: '❌ Type de média non supporté'
            })
            return
        }

        const mediaMessage = viewOnceMessage.message[`${mediaType}Message`]
        
        // Télécharger le média
        const buffer = await downloadMediaMessage(
            { message: { [mediaType + 'Message']: mediaMessage } },
            'buffer',
            {}
        )

        // Envoyer au propriétaire dans son privé
        await sock.sendMessage(ownerJid, {
            [mediaType]: buffer,
            caption: `🥷 *VUE UNIQUE TÉLÉCHARGÉE*\n\n📤 Envoyé par: @${senderNumber.split('@')[0]}\n📁 Type: ${mediaType}\n⏰ ${new Date().toLocaleString('fr-FR')}`,
            mentions: [senderNumber]
        })

        // Confirmer dans le chat
        await sock.sendMessage(remoteJid, {
            text: '✅ Média envoyé dans votre privé!'
        })

    } catch (error) {
        console.error('Erreur vv2:', error)
        await sock.sendMessage(remoteJid, {
            text: '❌ Erreur lors du téléchargement de la vue unique'
        })
    }
}
