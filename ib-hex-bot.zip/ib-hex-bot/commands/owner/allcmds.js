export async function allcmds(sock, message) {
    const remoteJid = message.key.remoteJid

    try {
        const commandsList = `╭──『 📋 TOUTES LES COMMANDES 』
│
│ 📁 *MENU* (6)
│ ⬡ menu, alive, dev, allvar, ping, owner
│
│ 📁 *OWNER* (9)
│ ⬡ join, leave, antidelete, upload, vv, 🥷
│ ⬡ allcmds, delete, repo
│
│ 📁 *IA* (6)
│ ⬡ ai, bug, bot, gemini, chatbot, gpt
│
│ 📁 *CONVERTISSEUR* (9)
│ ⬡ attp, toimage, gimage, mp3, ss
│ ⬡ fancy, url, sticker, take
│
│ 📁 *RECHERCHE* (10)
│ ⬡ google, play, video, song, mediafire
│ ⬡ facebook, instagram, tiktok, lyrics, image
│
│ 📁 *DIVERTISSEMENT* (9)
│ ⬡ getpp, goodnight, wcg, quizz, anime
│ ⬡ profile, couple, poll, emojimix
│
│ 📁 *GROUPES* (11)
│ ⬡ kickall, tagadmin, acceptall, tagall, getall
│ ⬡ add, vcf, linkgc, antilink, antisticker
│ ⬡ antigm, create, groupinfo
│
│ 📁 *RÉACTIONS* (10)
│ ⬡ yeet, slap, nom, poke, wave
│ ⬡ smile, dance, smug, cringe, happy
│
│ 📁 *EXTRA* (68)
│ ⬡ help, info, uptime, runtime, speed
│ ⬡ translate, weather, news, quote, joke
│ ⬡ fact, meme, gif, wallpaper, wikipedia
│ ⬡ calc, define, urban, crypto, bitcoin
│ ⬡ movie, imdb, spotify, youtube, ytmp3
│ ⬡ ytmp4, pinterest, reddit, twitter, npm
│ ⬡ github, apk, app, covid, qrcode
│ ⬡ barcode, currency, time, date, calendar
│ ⬡ countdown, reminder, note, notes, todo
│ ⬡ randomuser, randomfact, randomquote, dice
│ ⬡ coinflip, 8ball, choose, rps, slots
│ ⬡ truth, dare, wyr, trivia, math
│ ⬡ reverse, encode, decode, base64, binary
│ ⬡ hex, md5, sha1, hash, password
│ ⬡ randompass, uuid, shorturl, expandurl
│
│ 📁 *EFFETS* (136)
│ ⬡ neon, glow, thunder, fire, ice, blood
│ ⬡ matrix, scifi, retro, glitch, sketch, comic
│ ⬡ marvel, horror, graffiti, space, rainbow
│ ⬡ vintage, chocolate, berry, magma, sand
│ ⬡ wood, metal, gold, silver, diamond, carbon
│ ⬡ steel, glass, water, cloud, smoke, flame
│ ⬡ lava, ocean, forest, jungle, desert
│ ⬡ mountain, volcano, galaxy, nebula, planet
│ ⬡ star, moon, sun, aurora, lightning, storm
│ ⬡ tornado, earthquake, tsunami, flood
│ ⬡ avalanche, blizzard, hurricane, meteor
│ ⬡ comet, asteroid, blackhole, wormhole
│ ⬡ portal, dimension, universe, multiverse
│ ⬡ quantum, atom, molecule, cell, dna, rna
│ ⬡ protein, virus, bacteria, fungus, plant
│ ⬡ tree, flower, fruit, vegetable, animal
│ ⬡ bird, fish, insect, reptile, mammal
│ ⬡ dinosaur, dragon, unicorn, phoenix, griffin
│ ⬡ kraken, leviathan, behemoth, cerberus
│ ⬡ hydra, medusa, minotaur, centaur, pegasus
│ ⬡ chimera, sphinx, banshee, vampire
│ ⬡ werewolf, zombie, ghost, demon, angel
│ ⬡ fairy, elf, dwarf, giant, titan, god
│ ⬡ goddess, hero, villain, warrior, mage
│ ⬡ wizard, witch, sorcerer, necromancer
│ ⬡ paladin, knight, samurai, ninja, assassin
│ ⬡ thief, rogue, ranger, archer, hunter
│
╰─────────────────────
📊 Total: 200+ commandes
⚡ Préfixe: Ib
🥷 IB-HEX-BOT v1.0`

        await sock.sendMessage(remoteJid, {
            text: commandsList
        })

    } catch (error) {
        console.error('Erreur allcmds:', error)
        await sock.sendMessage(remoteJid, {
            text: '❌ Erreur lors de l\'affichage des commandes'
        })
    }
}
