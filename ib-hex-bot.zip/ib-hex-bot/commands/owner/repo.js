export async function repo(sock, message) {
    const remoteJid = message.key.remoteJid

    try {
        const repoText = `╭──『 📦 IB-HEX-BOT REPOSITORY 』
│
│ 🥷 *Bot:* IB-HEX-BOT
│ 👨‍💻 *Développeur:* Ibrahima Sory Sacko
│ ⚡ *Version:* 1.0
│ 📱 *WhatsApp:* 224621963059
│
│ 🔗 *GitHub:*
│ Créez votre propre dépôt avec
│ les fichiers fournis
│
│ 📋 *Fonctionnalités:*
│ ✅ 200+ commandes
│ ✅ Multi-device
│ ✅ Interface web QR Code
│ ✅ Hébergement Render
│ ✅ Français
│
╰─────────────────────

🥷 IB-HEX-BOT - Open Source`

        await sock.sendMessage(remoteJid, {
            text: repoText
        })

    } catch (error) {
        console.error('Erreur repo:', error)
        await sock.sendMessage(remoteJid, {
            text: '❌ Erreur lors de l\'affichage du dépôt'
        })
    }
}
