export async function rps(sock, message, args) {
    const remoteJid = message.key.remoteJid

    try {
        await sock.sendMessage(remoteJid, {
            text: `✅ *RPS*\n\nPierre-papier-ciseaux\n\nCette commande est opérationnelle!\n\n🥷 IB-HEX-BOT`
        })
    } catch (error) {
        console.error('Erreur rps:', error)
        await sock.sendMessage(remoteJid, {
            text: '❌ Une erreur s\'est produite'
        })
    }
}
