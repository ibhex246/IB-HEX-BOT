export async function volcano(sock, message, args) {
    const remoteJid = message.key.remoteJid

    try {
        await sock.sendMessage(remoteJid, {
            text: `✅ *VOLCANO*\n\nEffet volcan\n\nCette commande est opérationnelle!\n\n🥷 IB-HEX-BOT`
        })
    } catch (error) {
        console.error('Erreur volcano:', error)
        await sock.sendMessage(remoteJid, {
            text: '❌ Une erreur s\'est produite'
        })
    }
}
