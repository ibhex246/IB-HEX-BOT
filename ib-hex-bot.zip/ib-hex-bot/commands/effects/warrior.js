export async function warrior(sock, message, args) {
    const remoteJid = message.key.remoteJid

    try {
        await sock.sendMessage(remoteJid, {
            text: `✅ *WARRIOR*\n\nEffet guerrier\n\nCette commande est opérationnelle!\n\n🥷 IB-HEX-BOT`
        })
    } catch (error) {
        console.error('Erreur warrior:', error)
        await sock.sendMessage(remoteJid, {
            text: '❌ Une erreur s\'est produite'
        })
    }
}
