export async function ping(sock, message) {
    const remoteJid = message.key.remoteJid
    const start = Date.now()

    try {
        const sentMsg = await sock.sendMessage(remoteJid, {
            text: '⏳ Calcul de la vitesse...'
        })

        const end = Date.now()
        const latency = end - start

        await sock.sendMessage(remoteJid, {
            text: `🏓 *PONG!*\n\n⚡ Vitesse: ${latency}ms\n📊 Performance: ${latency < 100 ? 'Excellent' : latency < 300 ? 'Bon' : 'Moyen'}\n\n🥷 IB-HEX-BOT`,
            edit: sentMsg.key
        })

    } catch (error) {
        console.error('Erreur ping:', error)
        await sock.sendMessage(remoteJid, {
            text: '❌ Erreur lors du test de vitesse'
        })
    }
}
