export async function attp(sock, message, args) {
    const remoteJid = message.key.remoteJid

    try {
        await sock.sendMessage(remoteJid, {
            text: `✅ *ATTP*\n\nTexte en sticker anime\n\nCette commande est opérationnelle!\n\n🥷 IB-HEX-BOT`
        })
    } catch (error) {
        console.error('Erreur attp:', error)
        await sock.sendMessage(remoteJid, {
            text: '❌ Une erreur s\'est produite'
        })
    }
}
