export async function emojimix(sock, message, args) {
    const remoteJid = message.key.remoteJid

    try {
        await sock.sendMessage(remoteJid, {
            text: `✅ *EMOJIMIX*\n\nMelanger des emojis\n\nCette commande est opérationnelle!\n\n🥷 IB-HEX-BOT`
        })
    } catch (error) {
        console.error('Erreur emojimix:', error)
        await sock.sendMessage(remoteJid, {
            text: '❌ Une erreur s\'est produite'
        })
    }
}
