# 🥷 IB-HEX-BOT

Bot WhatsApp Multi-Device performant avec 200+ commandes fonctionnelles

## 🌟 Caractéristiques

- ✅ 200+ commandes fonctionnelles
- 🥷 Préfixe obligatoire "Ib"
- 🌐 Interface web pour QR Code
- 📱 Multi-device WhatsApp
- 🚀 Hébergement sur Render
- 🇫🇷 Entièrement en français

## 📋 Catégories de Commandes

### Menu (6 commandes)
- `Ibmenu` - Afficher le menu complet
- `Ibalive` - État du bot
- `Ibdev` - Informations développeur
- `Iballvar` - Toutes les variables
- `Ibping` - Vitesse du bot
- `Ibowner` - Propriétaire

### Owner (9 commandes)
- `Ibjoin` - Rejoindre un groupe
- `Ibleave` - Quitter un groupe
- `Ibantidelete` - Anti-suppression
- `Ibupload` - Téléverser
- `Ibvv` - Vue unique
- `Ib🥷` - Vue unique privé (téléchargement direct)
- `Iballcmds` - Toutes les commandes
- `Ibdelete` - Supprimer
- `Ibrepo` - Dépôt GitHub

### IA (6 commandes)
- `Ibai` - Intelligence artificielle
- `Ibbug` - Signaler un bug
- `Ibbot` - Informations bot
- `Ibgemini` - IA Gemini
- `Ibchatbot` - Discussion IA
- `Ibgpt` - ChatGPT

### Convertisseur (9 commandes)
- `Ibattp` - Texte en sticker
- `Ibtoimage` - Convertir en image
- `Ibgimage` - Image Google
- `Ibmp3` - Convertir en MP3
- `Ibss` - Capture d'écran
- `Ibfancy` - Texte stylé
- `Iburl` - Lien
- `Ibsticker` - Créer sticker
- `Ibtake` - Récupérer média

### Recherche (10 commandes)
- `Ibgoogle` - Recherche Google
- `Ibplay` - Play Store
- `Ibvideo` - Recherche vidéo
- `Ibsong` - Musique
- `Ibmediafire` - MediaFire
- `Ibfacebook` - Facebook
- `Ibinstagram` - Instagram
- `Ibtiktok` - TikTok
- `Iblyrics` - Paroles
- `Ibimage` - Images

### Divertissement (9 commandes)
- `Ibgetpp` - Photo de profil
- `Ibgoodnight` - Bonne nuit
- `Ibwcg` - Classement
- `Ibquizz` - Quiz
- `Ibanime` - Anime
- `Ibprofile` - Profil
- `Ibcouple` - Couple
- `Ibpoll` - Sondage
- `Ibemojimix` - Mélange d'emojis

### Groupes (13 commandes)
- `Ibkickall` - Exclure tous
- `Ibtagadmin` - Mention admins
- `Ibacceptall` - Accepter tous
- `Ibtagall` - Mentionner tous
- `Ibgetall` - Récupérer membres
- `Ibgroup close` - Fermer groupe
- `Ibgroup open` - Ouvrir groupe
- `Ibadd` - Ajouter membre
- `Ibvcf` - Contacts VCF
- `Iblinkgc` - Lien du groupe
- `Ibantilink` - Anti-lien
- `Ibantisticker` - Anti-sticker
- `Ibantigm` - Anti-mention
- `Ibcreate` - Créer groupe
- `Ibgroupinfo` - Infos groupe

### Réactions (10 commandes)
- `Ibyeet` - Jeter
- `Ibslap` - Gifler
- `Ibnom` - Manger
- `Ibpoke` - Toucher
- `Ibwave` - Saluer
- `Ibsmile` - Sourire
- `Ibdance` - Danser
- `Ibsmug` - Sourire narquois
- `Ibcringe` - Malaise
- `Ibhappy` - Heureux

### + 128 commandes supplémentaires dans Extra et Effects !

## 🚀 Déploiement sur Render

1. **Créer un compte sur [Render](https://render.com)**

2. **Créer un nouveau Web Service**
   - Connectez votre dépôt GitHub
   - Build Command: `npm install`
   - Start Command: `npm start`

3. **Variables d'environnement**
   - `PORT` : (auto-généré par Render)

4. **Accéder au QR Code**
   - Visitez l'URL de votre application Render
   - Scannez le QR code avec WhatsApp

## 📱 Installation Locale

```bash
# Cloner le dépôt
git clone <votre-repo>
cd ib-hex-bot

# Installer les dépendances
npm install

# Démarrer le bot
npm start

# Visitez http://localhost:3000
```

## ⚙️ Configuration

Modifiez `config.js` pour personnaliser :
- PREFIX : Préfixe des commandes (par défaut "Ib")
- OWNER_NUMBER : Votre numéro
- BOT_NAME : Nom du bot
- MENU_IMAGE : Image du menu

## 📞 Support

Propriétaire : Ibrahima Sory Sacko  
WhatsApp : 224621963059

## 📄 Licence

Développé par Ibrahima Sory Sacko  
Version 1.0  

## 🛠️ Technologies

- [Baileys](https://github.com/WhiskeySockets/Baileys) - WhatsApp Multi-Device
- Node.js
- Express
- QRCode

---

⚡ **IB-HEX-BOT** - Propulsé par Ibrahima Sory Sacko™ 🥷
