import config from '../config.js'
import * as commands from '../commands/index.js'

export async function handleMessage(sock, message) {
    try {
        const remoteJid = message.key.remoteJid
        const messageType = Object.keys(message.message)[0]
        
        let messageBody = ''
        
        if (messageType === 'conversation') {
            messageBody = message.message.conversation
        } else if (messageType === 'extendedTextMessage') {
            messageBody = message.message.extendedTextMessage.text
        } else if (messageType === 'imageMessage') {
            messageBody = message.message.imageMessage.caption || ''
        } else if (messageType === 'videoMessage') {
            messageBody = message.message.videoMessage.caption || ''
        }

        messageBody = messageBody.trim()

        // Vérifier le préfixe
        if (!messageBody.startsWith(config.PREFIX)) return

        // Extraire la commande
        const args = messageBody.slice(config.PREFIX.length).trim().split(/\s+/)
        const command = args[0].toLowerCase()
        const commandArgs = args.slice(1)

        console.log(`📥 Commande reçue: ${command} de ${remoteJid}`)

        // Auto-read
        if (config.AUTO_READ) {
            await sock.readMessages([message.key])
        }

        // Auto-typing
        if (config.AUTO_TYPING) {
            await sock.sendPresenceUpdate('composing', remoteJid)
        }

        // Router les commandes
        const commandMap = {
            // Menu
            'menu': commands.menu,
            'alive': commands.alive,
            'dev': commands.dev,
            'allvar': commands.allvar,
            'ping': commands.ping,
            'owner': commands.owner,

            // Owner
            'join': commands.join,
            'leave': commands.leave,
            'antidelete': commands.antidelete,
            'upload': commands.upload,
            'vv': commands.vv,
            '🥷': commands.vv2,
            'allcmds': commands.allcmds,
            'delete': commands.deleteMsg,
            'repo': commands.repo,

            // IA
            'ai': commands.ai,
            'bug': commands.bug,
            'bot': commands.botInfo,
            'gemini': commands.gemini,
            'chatbot': commands.chatbot,
            'gpt': commands.gpt,

            // Convertisseur
            'attp': commands.attp,
            'toimage': commands.toimage,
            'gimage': commands.gimage,
            'mp3': commands.mp3,
            'ss': commands.screenshot,
            'fancy': commands.fancy,
            'url': commands.url,
            'sticker': commands.sticker,
            'take': commands.take,

            // Recherche
            'google': commands.google,
            'play': commands.play,
            'video': commands.video,
            'song': commands.song,
            'mediafire': commands.mediafire,
            'facebook': commands.facebook,
            'instagram': commands.instagram,
            'tiktok': commands.tiktok,
            'lyrics': commands.lyrics,
            'image': commands.imageSearch,

            // Divertissement
            'getpp': commands.getpp,
            'goodnight': commands.goodnight,
            'wcg': commands.wcg,
            'quizz': commands.quizz,
            'anime': commands.anime,
            'profile': commands.profile,
            'couple': commands.couple,
            'poll': commands.poll,
            'emojimix': commands.emojimix,

            // Groupes
            'kickall': commands.kickall,
            'tagadmin': commands.tagadmin,
            'acceptall': commands.acceptall,
            'tagall': commands.tagall,
            'getall': commands.getall,
            'add': commands.add,
            'vcf': commands.vcf,
            'linkgc': commands.linkgc,
            'antilink': commands.antilink,
            'antisticker': commands.antisticker,
            'antigm': commands.antigm,
            'create': commands.create,
            'groupinfo': commands.groupinfo,

            // Réactions
            'yeet': commands.yeet,
            'slap': commands.slap,
            'nom': commands.nom,
            'poke': commands.poke,
            'wave': commands.wave,
            'smile': commands.smile,
            'dance': commands.dance,
            'smug': commands.smug,
            'cringe': commands.cringe,
            'happy': commands.happy,

            // Commandes supplémentaires (50-200)
            'help': commands.help,
            'info': commands.info,
            'uptime': commands.uptime,
            'runtime': commands.runtime,
            'speed': commands.speed,
            'translate': commands.translate,
            'weather': commands.weather,
            'news': commands.news,
            'quote': commands.quote,
            'joke': commands.joke,
            'fact': commands.fact,
            'meme': commands.meme,
            'gif': commands.gif,
            'wallpaper': commands.wallpaper,
            'wikipedia': commands.wikipedia,
            'wiki': commands.wikipedia,
            'calc': commands.calc,
            'calculator': commands.calc,
            'define': commands.define,
            'urban': commands.urban,
            'crypto': commands.crypto,
            'bitcoin': commands.bitcoin,
            'movie': commands.movie,
            'imdb': commands.imdb,
            'spotify': commands.spotify,
            'youtube': commands.youtube,
            'yt': commands.youtube,
            'ytmp3': commands.ytmp3,
            'ytmp4': commands.ytmp4,
            'pinterest': commands.pinterest,
            'reddit': commands.reddit,
            'twitter': commands.twitter,
            'tweet': commands.twitter,
            'npm': commands.npm,
            'github': commands.github,
            'apk': commands.apk,
            'app': commands.app,
            'covid': commands.covid,
            'corona': commands.covid,
            'qr': commands.qrcode,
            'qrcode': commands.qrcode,
            'barcode': commands.barcode,
            'currency': commands.currency,
            'exchange': commands.currency,
            'time': commands.time,
            'date': commands.date,
            'calendar': commands.calendar,
            'countdown': commands.countdown,
            'reminder': commands.reminder,
            'note': commands.note,
            'notes': commands.notes,
            'todo': commands.todo,
            'randomuser': commands.randomuser,
            'randomfact': commands.randomfact,
            'randomquote': commands.randomquote,
            'dice': commands.dice,
            'coinflip': commands.coinflip,
            '8ball': commands.eightball,
            'choose': commands.choose,
            'rps': commands.rps,
            'slots': commands.slots,
            'truth': commands.truth,
            'dare': commands.dare,
            'wyr': commands.wyr,
            'trivia': commands.trivia,
            'math': commands.math,
            'reverse': commands.reverse,
            'encode': commands.encode,
            'decode': commands.decode,
            'base64': commands.base64,
            'binary': commands.binary,
            'hex': commands.hex,
            'md5': commands.md5,
            'sha1': commands.sha1,
            'hash': commands.hash,
            'password': commands.password,
            'randompass': commands.randompass,
            'uuid': commands.uuid,
            'shorturl': commands.shorturl,
            'expandurl': commands.expandurl,
            'neon': commands.neon,
            'glow': commands.glow,
            'thunder': commands.thunder,
            'fire': commands.fire,
            'ice': commands.ice,
            'blood': commands.blood,
            'matrix': commands.matrix,
            'sci-fi': commands.scifi,
            'retro': commands.retro,
            'glitch': commands.glitch,
            'sketch': commands.sketch,
            'comic': commands.comic,
            'blood2': commands.blood2,
            'marvel': commands.marvel,
            'horror': commands.horror,
            'graffiti': commands.graffiti,
            'space': commands.space,
            'rainbow': commands.rainbow,
            'vintage': commands.vintage,
            'chocolate': commands.chocolate,
            'berry': commands.berry,
            'magma': commands.magma,
            'sand': commands.sand,
            'wood': commands.wood,
            'metal': commands.metal,
            'gold': commands.gold,
            'silver': commands.silver,
            'diamond': commands.diamond,
            'carbon': commands.carbon,
            'steel': commands.steel,
            'glass': commands.glass,
            'ice2': commands.ice2,
            'water': commands.water,
            'cloud': commands.cloud,
            'smoke': commands.smoke,
            'flame': commands.flame,
            'lava': commands.lava,
            'ocean': commands.ocean,
            'forest': commands.forest,
            'jungle': commands.jungle,
            'desert': commands.desert,
            'mountain': commands.mountain,
            'volcano': commands.volcano,
            'galaxy': commands.galaxy,
            'nebula': commands.nebula,
            'planet': commands.planet,
            'star': commands.star,
            'moon': commands.moon,
            'sun': commands.sun,
            'aurora': commands.aurora,
            'lightning': commands.lightning,
            'storm': commands.storm,
            'tornado': commands.tornado,
            'earthquake': commands.earthquake,
            'tsunami': commands.tsunami,
            'flood': commands.flood,
            'avalanche': commands.avalanche,
            'blizzard': commands.blizzard,
            'hurricane': commands.hurricane,
            'meteor': commands.meteor,
            'comet': commands.comet,
            'asteroid': commands.asteroid,
            'blackhole': commands.blackhole,
            'wormhole': commands.wormhole,
            'portal': commands.portal,
            'dimension': commands.dimension,
            'universe': commands.universe,
            'multiverse': commands.multiverse,
            'quantum': commands.quantum,
            'atom': commands.atom,
            'molecule': commands.molecule,
            'cell': commands.cell,
            'dna': commands.dna,
            'rna': commands.rna,
            'protein': commands.protein,
            'virus': commands.virus,
            'bacteria': commands.bacteria,
            'fungus': commands.fungus,
            'plant': commands.plant,
            'tree': commands.tree,
            'flower': commands.flower,
            'fruit': commands.fruit,
            'vegetable': commands.vegetable,
            'animal': commands.animal,
            'bird': commands.bird,
            'fish': commands.fish,
            'insect': commands.insect,
            'reptile': commands.reptile,
            'mammal': commands.mammal,
            'dinosaur': commands.dinosaur,
            'dragon': commands.dragon,
            'unicorn': commands.unicorn,
            'phoenix': commands.phoenix,
            'griffin': commands.griffin,
            'kraken': commands.kraken,
            'leviathan': commands.leviathan,
            'behemoth': commands.behemoth,
            'cerberus': commands.cerberus,
            'hydra': commands.hydra,
            'medusa': commands.medusa,
            'minotaur': commands.minotaur,
            'centaur': commands.centaur,
            'pegasus': commands.pegasus,
            'chimera': commands.chimera,
            'sphinx': commands.sphinx,
            'banshee': commands.banshee,
            'vampire': commands.vampire,
            'werewolf': commands.werewolf,
            'zombie': commands.zombie,
            'ghost': commands.ghost,
            'demon': commands.demon,
            'angel': commands.angel,
            'fairy': commands.fairy,
            'elf': commands.elf,
            'dwarf': commands.dwarf,
            'giant': commands.giant,
            'titan': commands.titan,
            'god': commands.god,
            'goddess': commands.goddess,
            'hero': commands.hero,
            'villain': commands.villain,
            'warrior': commands.warrior,
            'mage': commands.mage,
            'wizard': commands.wizard,
            'witch': commands.witch,
            'sorcerer': commands.sorcerer,
            'necromancer': commands.necromancer,
            'paladin': commands.paladin,
            'knight': commands.knight,
            'samurai': commands.samurai,
            'ninja': commands.ninja,
            'assassin': commands.assassin,
            'thief': commands.thief,
            'rogue': commands.rogue,
            'ranger': commands.ranger,
            'archer': commands.archer,
            'hunter': commands.hunter
        }

        // Exécuter la commande
        if (commandMap[command]) {
            try {
                await commandMap[command](sock, message, commandArgs)
            } catch (error) {
                console.error(`❌ Erreur lors de l'exécution de ${command}:`, error)
                await sock.sendMessage(remoteJid, {
                    text: `❌ Une erreur s'est produite lors de l'exécution de la commande *${command}*`
                })
            }
        }

        // Arrêter l'indicateur de saisie
        if (config.AUTO_TYPING) {
            await sock.sendPresenceUpdate('paused', remoteJid)
        }

    } catch (error) {
        console.error('❌ Erreur handleMessage:', error)
    }
}
