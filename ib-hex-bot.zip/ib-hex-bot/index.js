import { makeWASocket, DisconnectReason, useMultiFileAuthState, fetchLatestBaileysVersion, makeCacheableSignalKeyStore } from '@whiskeysockets/baileys'
import pino from 'pino'
import express from 'express'
import qrcode from 'qrcode'
import config from './config.js'
import { handleMessage } from './utils/messageHandler.js'

const app = express()
let qrCodeData = null
let sock = null

// Serveur web pour afficher le QR Code
app.get('/', (req, res) => {
    if (qrCodeData) {
        res.send(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>IB-HEX-BOT - Connexion</title>
                <style>
                    body {
                        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        min-height: 100vh;
                        margin: 0;
                        padding: 20px;
                    }
                    .container {
                        background: white;
                        border-radius: 20px;
                        padding: 40px;
                        box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                        text-align: center;
                        max-width: 500px;
                    }
                    h1 {
                        color: #667eea;
                        margin-bottom: 10px;
                        font-size: 2.5em;
                    }
                    .subtitle {
                        color: #666;
                        margin-bottom: 30px;
                        font-size: 1.1em;
                    }
                    #qrcode {
                        margin: 20px auto;
                        padding: 20px;
                        background: white;
                        border-radius: 10px;
                        display: inline-block;
                    }
                    .instructions {
                        background: #f8f9fa;
                        border-radius: 10px;
                        padding: 20px;
                        margin-top: 20px;
                        text-align: left;
                    }
                    .instructions h3 {
                        color: #667eea;
                        margin-top: 0;
                    }
                    .instructions ol {
                        padding-left: 20px;
                    }
                    .instructions li {
                        margin: 10px 0;
                        color: #444;
                    }
                    .footer {
                        margin-top: 30px;
                        color: #888;
                        font-size: 0.9em;
                    }
                    .emoji {
                        font-size: 1.5em;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>🥷 IB-HEX-BOT</h1>
                    <p class="subtitle">Bot WhatsApp Multi-Device</p>
                    <div id="qrcode"></div>
                    <div class="instructions">
                        <h3>📱 Instructions de connexion :</h3>
                        <ol>
                            <li>Ouvrez WhatsApp sur votre téléphone</li>
                            <li>Allez dans <strong>Paramètres</strong> > <strong>Appareils liés</strong></li>
                            <li>Appuyez sur <strong>Lier un appareil</strong></li>
                            <li>Scannez ce QR code</li>
                        </ol>
                    </div>
                    <div class="footer">
                        <p><span class="emoji">⚡</span> Développé par <strong>${config.DEVELOPER}</strong></p>
                        <p>Version ${config.VERSION}</p>
                    </div>
                </div>
                <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js"></script>
                <script>
                    QRCode.toCanvas('${qrCodeData}', { 
                        width: 300,
                        margin: 2,
                        color: {
                            dark: '#667eea',
                            light: '#ffffff'
                        }
                    }, function(error, canvas) {
                        if (error) console.error(error)
                        document.getElementById('qrcode').appendChild(canvas)
                    })
                    
                    // Auto-refresh toutes les 30 secondes
                    setTimeout(() => location.reload(), 30000)
                </script>
            </body>
            </html>
        `)
    } else {
        res.send(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>IB-HEX-BOT - Connecté</title>
                <style>
                    body {
                        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        min-height: 100vh;
                        margin: 0;
                    }
                    .container {
                        background: white;
                        border-radius: 20px;
                        padding: 60px;
                        box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                        text-align: center;
                    }
                    .success {
                        color: #28a745;
                        font-size: 4em;
                        margin-bottom: 20px;
                    }
                    h1 {
                        color: #667eea;
                        margin-bottom: 20px;
                    }
                    p {
                        color: #666;
                        font-size: 1.2em;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="success">✅</div>
                    <h1>IB-HEX-BOT Connecté !</h1>
                    <p>Le bot est maintenant actif sur WhatsApp</p>
                    <p style="margin-top: 30px; font-size: 0.9em; color: #888;">
                        Utilisez le préfixe <strong>Ib</strong> pour les commandes
                    </p>
                </div>
            </body>
            </html>
        `)
    }
})

app.get('/status', (req, res) => {
    res.json({
        status: sock ? 'connected' : 'disconnected',
        botName: config.BOT_NAME,
        version: config.VERSION
    })
})

// Fonction de connexion WhatsApp
async function connectToWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info_baileys')
    const { version } = await fetchLatestBaileysVersion()

    sock = makeWASocket({
        version,
        logger: pino({ level: 'silent' }),
        printQRInTerminal: false,
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' }))
        },
        browser: ['IB-HEX-BOT', 'Chrome', '1.0.0'],
        markOnlineOnConnect: true,
        generateHighQualityLinkPreview: true,
        getMessage: async () => ({ conversation: 'IB-HEX-BOT' })
    })

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update

        if (qr) {
            qrCodeData = qr
            console.log('🔗 QR Code généré ! Visitez http://localhost:' + config.PORT)
        }

        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut
            console.log('❌ Connexion fermée. Reconnexion:', shouldReconnect)
            
            if (shouldReconnect) {
                connectToWhatsApp()
            }
        } else if (connection === 'open') {
            qrCodeData = null
            console.log('✅ IB-HEX-BOT connecté avec succès!')
            console.log('🥷 Bot: ' + config.BOT_NAME)
            console.log('👤 Propriétaire: ' + config.OWNER_NAME)
            console.log('📱 Préfixe: ' + config.PREFIX)
        }
    })

    sock.ev.on('creds.update', saveCreds)

    sock.ev.on('messages.upsert', async ({ messages }) => {
        const message = messages[0]
        if (!message.message || message.key.fromMe) return

        await handleMessage(sock, message)
    })

    sock.ev.on('group-participants.update', async (update) => {
        console.log('Mise à jour du groupe:', update)
    })
}

// Démarrage du serveur et connexion
app.listen(config.PORT, () => {
    console.log(`🌐 Serveur web démarré sur le port ${config.PORT}`)
    console.log(`🔗 Visitez: http://localhost:${config.PORT}`)
    connectToWhatsApp()
})
