# 🚀 DÉMARRAGE RAPIDE - IB-HEX-BOT

## ⚡ 5 Minutes pour déployer votre bot WhatsApp!

### Étape 1 : GitHub (2 minutes)

1. Allez sur https://github.com/new
2. Nom du dépôt : `ib-hex-bot`
3. Cochez "Public"
4. Cliquez "Create repository"

**Uploader les fichiers :**
- Cliquez sur "uploading an existing file"
- Glissez-déposez TOUT le contenu du dossier `ib-hex-bot`
- Cliquez "Commit changes"

### Étape 2 : Render (2 minutes)

1. Allez sur https://render.com
2. Inscrivez-vous avec GitHub
3. Cliquez "New +" → "Web Service"
4. Sélectionnez votre dépôt `ib-hex-bot`

**Configuration :**
```
Name: ib-hex-bot
Build Command: npm install
Start Command: npm start
Plan: Free
```

5. Cliquez "Create Web Service"

### Étape 3 : Scanner QR Code (1 minute)

1. Attendez que le déploiement se termine
2. Copiez l'URL de votre service (ex: `https://ib-hex-bot.onrender.com`)
3. Ouvrez l'URL dans votre navigateur
4. Sur WhatsApp : **Paramètres** → **Appareils liés** → **Lier un appareil**
5. Scannez le QR code

### ✅ C'est tout !

Votre bot est maintenant en ligne 24/7 !

## 🎯 Premiers Tests

Envoyez ces commandes sur WhatsApp :

```
Ibmenu
```
Pour voir le menu complet

```
Ibping
```
Pour tester la vitesse

```
Iballcmds
```
Pour voir toutes les 200+ commandes

## 📱 Commandes Essentielles

| Commande | Description |
|----------|-------------|
| `Ibmenu` | Menu complet |
| `Ibping` | Test vitesse |
| `Ibtagall` | Mentionner tous (groupe) |
| `Ibtagadmin` | Mentionner admins |
| `Ib🥷` | Vue unique privé |
| `Iballcmds` | Toutes les commandes |

## ⚙️ Personnalisation

Modifiez `config.js` sur GitHub :

```javascript
OWNER_NUMBER: '224621963059',  // ← Changez avec VOTRE numéro
BOT_NAME: 'IB-HEX-BOT',        // ← Nom de votre bot
OWNER_NAME: 'Votre Nom',       // ← Votre nom
```

Puis sur Render :
- "Manual Deploy" → "Clear build cache & deploy"

## 🔧 Maintenance

### Redémarrer le bot
Render Dashboard → Votre service → "Manual Deploy" → "Deploy latest commit"

### Voir les logs
Render Dashboard → Votre service → "Logs"

### Mettre à jour le code
1. Modifiez sur GitHub
2. Render redéploie automatiquement

## ❓ Problèmes Courants

**Bot ne répond pas ?**
- Vérifiez le préfixe `Ib`
- Le bot est sensible à la casse

**QR Code ne s'affiche pas ?**
- Attendez 2-3 minutes après le déploiement
- Vérifiez les logs sur Render

**Bot s'endort ?**
- Normal sur plan Free après 15 min d'inactivité
- Utilisez UptimeRobot pour le garder actif

## 📞 Support

**WhatsApp :** 224621963059  
**Développeur :** Ibrahima Sory Sacko

## 📚 Documentation Complète

- `README.md` - Vue d'ensemble
- `INSTALLATION.md` - Installation détaillée
- `DEPLOYMENT.md` - Déploiement détaillé
- `COMMANDES.md` - Liste des 200+ commandes

---

⚡ Profitez de votre **IB-HEX-BOT** ! 🥷
