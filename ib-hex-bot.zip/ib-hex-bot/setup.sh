#!/bin/bash

echo "🥷 IB-HEX-BOT - Configuration Git"
echo "=================================="
echo ""

# Initialiser Git
git init

# Ajouter tous les fichiers
git add .

# Premier commit
git commit -m "Initial commit - IB-HEX-BOT avec 200+ commandes"

echo ""
echo "✅ Git initialisé avec succès!"
echo ""
echo "📝 Prochaines étapes:"
echo "1. Créez un dépôt sur GitHub"
echo "2. Exécutez ces commandes (remplacez VOTRE_USERNAME):"
echo ""
echo "   git remote add origin https://github.com/VOTRE_USERNAME/ib-hex-bot.git"
echo "   git branch -M main"
echo "   git push -u origin main"
echo ""
echo "3. Déployez sur Render (voir DEPLOYMENT.md)"
echo ""
echo "🥷 IB-HEX-BOT prêt pour le déploiement!"
