# 📋 LISTE COMPLÈTE DES COMMANDES - IB-HEX-BOT

## ⚠️ Important
**TOUTES les commandes nécessitent le préfixe `Ib`**

Exemple : `Ibmenu`, `Ibping`, `Ibtagall`

---

## 📁 MENU (6 commandes)

| Commande | Description |
|----------|-------------|
| `Ibmenu` | Affiche le menu complet avec image |
| `Ibalive` | Vérifie si le bot est en ligne |
| `Ibdev` | Informations sur le développeur |
| `Iballvar` | Affiche toutes les variables |
| `Ibping` | Teste la vitesse de réponse du bot |
| `Ibowner` | Informations sur le propriétaire |

---

## 👑 OWNER (9 commandes)

| Commande | Description |
|----------|-------------|
| `Ibjoin [lien]` | Rejoindre un groupe via lien d'invitation |
| `Ibleave` | Quitter le groupe actuel |
| `Ibantidelete` | Activer/désactiver l'anti-suppression |
| `Ibupload` | Téléverser un fichier |
| `Ibvv` | Voir un message en vue unique |
| `Ib🥷` | Vue unique privé - téléchargement direct dans le privé du propriétaire |
| `Iballcmds` | Liste toutes les commandes disponibles |
| `Ibdelete` | Supprimer un message |
| `Ibrepo` | Informations sur le dépôt GitHub |

---

## 🤖 IA (6 commandes)

| Commande | Description |
|----------|-------------|
| `Ibai [question]` | Intelligence artificielle générale |
| `Ibbug [description]` | Signaler un bug |
| `Ibbot` | Informations sur le bot |
| `Ibgemini [question]` | IA Google Gemini |
| `Ibchatbot [message]` | Discussion avec IA |
| `Ibgpt [question]` | ChatGPT OpenAI |

---

## 🔄 CONVERTISSEUR (9 commandes)

| Commande | Description |
|----------|-------------|
| `Ibattp [texte]` | Convertir texte en sticker animé |
| `Ibtoimage` | Convertir sticker en image |
| `Ibgimage [recherche]` | Rechercher une image sur Google |
| `Ibmp3` | Convertir vidéo en MP3 |
| `Ibss [url]` | Capture d'écran d'un site web |
| `Ibfancy [texte]` | Créer du texte stylé |
| `Iburl [lien]` | Raccourcir une URL |
| `Ibsticker` | Créer un sticker depuis image/vidéo |
| `Ibtake [nom]` | Modifier un sticker |

---

## 🔍 RECHERCHE (10 commandes)

| Commande | Description |
|----------|-------------|
| `Ibgoogle [recherche]` | Recherche Google |
| `Ibplay [app]` | Recherche sur Play Store |
| `Ibvideo [recherche]` | Rechercher vidéo YouTube |
| `Ibsong [titre]` | Rechercher une musique |
| `Ibmediafire [lien]` | Télécharger depuis MediaFire |
| `Ibfacebook [lien]` | Télécharger vidéo Facebook |
| `Ibinstagram [lien]` | Télécharger depuis Instagram |
| `Ibtiktok [lien]` | Télécharger vidéo TikTok |
| `Iblyrics [chanson]` | Obtenir les paroles |
| `Ibimage [recherche]` | Rechercher des images |

---

## 🎮 DIVERTISSEMENT (9 commandes)

| Commande | Description |
|----------|-------------|
| `Ibgetpp [@mention]` | Obtenir la photo de profil |
| `Ibgoodnight` | Image de bonne nuit |
| `Ibwcg` | Classement du groupe |
| `Ibquizz` | Démarrer un quiz |
| `Ibanime` | Image anime aléatoire |
| `Ibprofile` | Voir votre carte de profil |
| `Ibcouple [@mention1 @mention2]` | Test de compatibilité |
| `Ibpoll [question]` | Créer un sondage |
| `Ibemojimix [emoji1 emoji2]` | Mélanger des emojis |

---

## 👥 GROUPES (13 commandes)

| Commande | Description |
|----------|-------------|
| `Ibkickall` | Exclure tous les membres (admin) |
| `Ibtagadmin` | Mentionner tous les administrateurs |
| `Ibacceptall` | Accepter toutes les demandes (admin) |
| `Ibtagall` | Mentionner tous les membres |
| `Ibgetall` | Liste de tous les membres |
| `Ibgroup close` | Fermer le groupe (admin) |
| `Ibgroup open` | Ouvrir le groupe (admin) |
| `Ibadd [numéro]` | Ajouter un membre |
| `Ibvcf` | Exporter les contacts en VCF |
| `Iblinkgc` | Obtenir le lien du groupe |
| `Ibantilink` | Activer anti-lien |
| `Ibantisticker` | Activer anti-sticker |
| `Ibantigm` | Activer anti-mention globale |
| `Ibcreate [nom]` | Créer un nouveau groupe |
| `Ibgroupinfo` | Informations du groupe |

---

## 😄 RÉACTIONS (10 commandes)

| Commande | Description |
|----------|-------------|
| `Ibyeet` | Animation jeter |
| `Ibslap [@mention]` | Animation gifler |
| `Ibnom` | Animation manger |
| `Ibpoke [@mention]` | Animation toucher |
| `Ibwave` | Animation saluer |
| `Ibsmile` | Animation sourire |
| `Ibdance` | Animation danser |
| `Ibsmug` | Animation sourire narquois |
| `Ibcringe` | Animation malaise |
| `Ibhappy` | Animation heureux |

---

## ⚡ EXTRA (68 commandes)

| Catégorie | Commandes |
|-----------|-----------|
| **Aide** | `Ibhelp`, `Ibinfo` |
| **Système** | `Ibuptime`, `Ibruntime`, `Ibspeed` |
| **Traduction** | `Ibtranslate` |
| **Météo** | `Ibweather` |
| **Actualités** | `Ibnews` |
| **Citations** | `Ibquote`, `Ibrandomquote` |
| **Divertissement** | `Ibjoke`, `Ibfact`, `Ibmeme`, `Ibgif` |
| **Images** | `Ibwallpaper` |
| **Recherche** | `Ibwikipedia`, `Ibdefine`, `Ibur ban` |
| **Crypto** | `Ibcrypto`, `Ibbitcoin` |
| **Films** | `Ibmovie`, `Ibimdb` |
| **Musique** | `Ibspotify`, `Ibyoutube`, `Ibytmp3`, `Ibytmp4` |
| **Réseaux** | `Ibpinterest`, `Ibred dit`, `Ibtwitter` |
| **Dev** | `Ibnpm`, `Ibgithub` |
| **Apps** | `Ibapk`, `Ibapp` |
| **COVID** | `Ibcovid` |
| **Codes** | `Ibqrcode`, `Ibbarcode` |
| **Monnaie** | `Ibcurrency` |
| **Temps** | `Ibtime`, `Ibdate`, `Ibcalendar`, `Ibcountdown` |
| **Notes** | `Ibreminder`, `Ibnote`, `Ibnotes`, `Ibtodo` |
| **Aléatoire** | `Ibrandomuser`, `Ibrandomfact` |
| **Jeux** | `Ibdice`, `Ibcoinflip`, `Ib8ball`, `Ibchoose`, `Ibrps`, `Ibslots` |
| **Social** | `Ibtruth`, `Ibdare`, `Ibwyr` |
| **Éducation** | `Ibtrivia`, `Ibmath` |
| **Encodage** | `Ibreverse`, `Ibencode`, `Ibdecode`, `Ibbase64`, `Ibbinary`, `Ibhex` |
| **Sécurité** | `Ibmd5`, `Ibsha1`, `Ibhash`, `Ibpassword`, `Ibrandompass`, `Ibuuid` |
| **URL** | `Ibshorturl`, `Ibexpandurl` |

---

## 🎨 EFFETS DE TEXTE (136 commandes)

### Effets Visuels
- `Ibneon`, `Ibglow`, `Ibthunder`, `Ibfire`, `Ibice`, `Ibblood`
- `Ibmatrix`, `Ibscifi`, `Ibretro`, `Ibglitch`, `Ibsketch`, `Ibcomic`
- `Ibmarvel`, `Ibhorror`, `Ibgraffiti`, `Ibspace`, `Ibrainbow`, `Ibvintage`

### Matériaux
- `Ibchocolate`, `Ibberry`, `Ibmagma`, `Ibsand`, `Ibwood`, `Ibmetal`
- `Ibgold`, `Ibsilver`, `Ibdiamond`, `Ibcarbon`, `Ibsteel`, `Ibglass`

### Éléments Naturels
- `Ibwater`, `Ibcloud`, `Ibsmoke`, `Ibflame`, `Iblava`, `Ibocean`
- `Ibforest`, `Ibjungle`, `Ibdesert`, `Ibmountain`, `Ibvolcano`

### Espace
- `Ibgalaxy`, `Ibnebula`, `Ibplanet`, `Ibstar`, `Ibmoon`, `Ibsun`
- `Ibaurora`, `Iblightning`, `Ibstorm`, `Ibtornado`

### Catastrophes
- `Ibearthquake`, `Ibtsunami`, `Ibflood`, `Ibavalanche`, `Ibblizzard`
- `Ibhurricane`, `Ibmeteor`, `Ibcomet`, `Ibasteroid`

### Science-Fiction
- `Ibblackhole`, `Ibwormhole`, `Ibportal`, `Ibdimension`, `Ibuniverse`
- `Ibmultiverse`, `Ibquantum`, `Ibatom`, `Ibmolecule`, `Ibcell`

### Biologie
- `Ibdna`, `Ibrna`, `Ibprotein`, `Ibvirus`, `Ibbacteria`, `Ibfungus`
- `Ibplant`, `Ibtree`, `Ibflower`, `Ibfruit`, `Ibvegetable`

### Animaux
- `Ibanimal`, `Ibbird`, `Ibfish`, `Ibinsect`, `Ibreptile`, `Ibmammal`
- `Ibdinosaur`

### Créatures Mythiques
- `Ibdragon`, `Ibunicorn`, `Ibphoenix`, `Ibgriffin`, `Ibkraken`
- `Ibleviathan`, `Ibbehemoth`, `Ibcerberus`, `Ibhydra`, `Ibmedusa`
- `Ibminotaur`, `Ibcentaur`, `Ibpegasus`, `Ibchimera`, `Ibsphinx`

### Créatures Surnaturelles
- `Ibbanshee`, `Ibvampire`, `Ibwerewolf`, `Ibzombie`, `Ibghost`
- `Ibdemon`, `Ibangel`, `Ibfairy`, `Ibelf`, `Ibdwarf`, `Ibgiant`, `Ibtitan`

### Divinités
- `Ibgod`, `Ibgoddess`

### Personnages
- `Ibhero`, `Ibvillain`, `Ibwarrior`, `Ibmage`, `Ibwizard`, `Ibwitch`
- `Ibsorcerer`, `Ibnecromancer`, `Ibpaladin`, `Ibknight`, `Ibsamurai`
- `Ibninja`, `Ibassassin`, `Ibthief`, `Ibrogue`, `Ibranger`, `Ibarcher`, `Ibhunter`

---

## 📊 Statistiques

- **Total de commandes** : 200+
- **Catégories** : 10
- **Préfixe obligatoire** : `Ib`
- **Langue** : 100% Français

---

## 💡 Conseils d'utilisation

1. **Toujours utiliser le préfixe** : Sans `Ib`, le bot ne répond pas
2. **Respecter la casse** : Les commandes sont sensibles à la casse
3. **Groupes vs Privé** : Certaines commandes ne fonctionnent que dans les groupes
4. **Permissions** : Les commandes admin nécessitent les droits administrateur

---

## 🆘 Aide

Pour plus d'aide :
- Utilisez `Ibhelp`
- Contactez : 224621963059 (WhatsApp)
- Développeur : Ibrahima Sory Sacko

---

⚡ **IB-HEX-BOT v1.0** - 200+ Commandes Opérationnelles 🥷
